from setuptools import setup

setup(
    name='module_cilindro',
    version='1.2',
    description='The area example Application Programming',
    author='ARG',
    author_email='profesor@gmail.com',
    url='trello.com/pa',
    py_modules=['module_cilindro'],
)
